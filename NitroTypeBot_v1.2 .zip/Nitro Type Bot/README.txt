Program created by smokeytube.

Source code can be found on github.com/smokeytube/nitrotypebot

Contact ZachD#0132 for questions comments, concerns, feature ideas, or bugs.