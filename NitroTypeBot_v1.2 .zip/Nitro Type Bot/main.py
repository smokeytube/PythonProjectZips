import sys, random, time
import lxml
from selenium import webdriver
print ("""
 _______  .__  __                 __                          __________        __   
 \      \ |__|/  |________  _____/  |_ ___.__.______   ____   \______   \ _____/  |_ 
 /   |   \|  \   __\_  __ \/  _ \   __<   |  |\____ \_/ __ \   |    |  _//  _ \   __|
/    |    \  ||  |  |  | \(  <_> )  |  \___  ||  |_> >  ___/   |    |   (  <_> )  |  
\____|__  /__||__|  |__|   \____/|__|  / ____||   __/ \___  >  |______  /\____/|__|  
        \/                             \/     |__|        \/          \/            
""")
chromedriverdir = 'chromedriver86.exe'

print ("1} Type on your account (~100 wpm)")
print ('\n')
print ("2} Type as guest (~100 wpm)")
print ("3} Instant type as guest! (4,000-10,000 wpm)")
print ('\n')
print ("Press '~' for the manual start")
print ("4} Manual start on account (80-110wpm)")
print ("5} Manual start on guest (6,000-12,000wpm)")
print ('\n')
print ("6} How to use this program (youtube video)")
print ('\n')


inputnumb = int(input("Select an option: "))

if inputnumb == 1:
#bot
     
    import string
    import pyautogui
    import time
    from bs4 import BeautifulSoup
    import random
    USERN = input("Username: ")
    PASSW = input("Password: ")
    driver = webdriver.Chrome(chromedriverdir)
    driver.implicitly_wait(5)
    driver.get('https://www.nitrotype.com/login')
    driver.find_element_by_xpath('//*[@id="username"]').send_keys(USERN)
    driver.find_element_by_xpath('//*[@id="password"]').send_keys(PASSW)
    driver.find_element_by_xpath('//*[@id="root"]/div/div/main/div/section/div[2]/div/div[3]/form/button').click()
    driver.find_element_by_xpath('//*[@id="root"]/div/header/div/div[3]/div[1]/a').click()
    x = 0
    while x != 1:
        try:
            driver.find_element_by_xpath('//*[@id="raceContainer"]/div[4]/div[1]/div[1]/div[2]/div[1]/div')
            x = x+1
        except:
            pass

        try:
            driver.find_element_by_xpath('//*[@id="raceContainer"]/div[3]/div[1]/div[1]/div[2]/div[1]/div')
            x = x+1
        except:
            pass
    def what():
        htmlsrc = driver.page_source
        htmlpaste = open('textfiles/html_src.txt', 'w')
        htmlpaste.write(htmlsrc)
        htmlpaste.close()
        htmlreplace = open("textfiles/html_src.txt", "rt")
        data = htmlreplace.read()
        htmlreplace.close()
        data = data.replace('&nbsp;', ' ')
        htmlreplace = open("textfiles/html_src.txt", "wt")
        htmlreplace.write(data)
        htmlreplace.close()
        htmlfile = open('textfiles/html_src.txt', 'r')
        soup = BeautifulSoup(htmlfile, 'lxml')
        htmlfile.close()
        span = soup.find_all('span', class_='dash-letter')
        with open('textfiles/spans.txt', 'w') as f:
            for spans in span:
                f.write(spans.text)
            f.close()
        spantxt = open('textfiles/spans.txt', 'r+')
        spantxtdata = spantxt.read()
        spantxt.close()
        spans2txt = open('textfiles/span2.txt', 'r+')
        for word in spantxtdata:
            listword = list(word)
            for letter in listword:
                spans2txt.write(letter + '\n')
        spans2txt.close()
        def randomdec():
            rando = random.randint(1,30)
            if rando == 1:
                time.sleep(0.1)
            if rando == 2:
                time.sleep(0.2)
            else:
                time.sleep(0)
        def randommistake():
            randlet = random.randint(1,50)
            if randlet == 1:
                string.ascii_letters
                pyautogui.typewrite(random.choice(string.ascii_letters))
        writetype = open('textfiles/span2.txt', 'r+')
        for letter in writetype:
            letter = letter.strip('\n')
            pyautogui.typewrite(letter)
            randomdec()
            randommistake()
        writetype.truncate(0)
        writetype.close()
    def typing():
        try:
            q = driver.find_element_by_xpath('//*[@id="raceContainer"]/div[3]/div[1]/div[1]/div[2]/div[2]')
            if q:
                q.click()
                what()
            else:
                pass
        except:
            pass              
    while True:
        typing()
        try:
            q = driver.find_element_by_xpath('//*[@id="root"]/div[1]/div/div[1]/button')
            if q:
                q.click()
        except:
            pass

        typing()

        try:
            q = driver.find_element_by_xpath('//*[@id="raceContainer"]/div[1]/div[2]/div[3]/div/div[2]/button')
            if q:
                q.click()
        except:
            pass

        typing()

        try:
            q = driver.find_elements_by_xpath('//*[@id="raceContainer"]/div[1]/div[1]/div/div/div/div[2]/button')
            if q:
                q.click()
        except:
            pass

        typing()

        try:
            q = driver.find_elements_by_xpath('//*[@id="root"]/div[1]/div[1]/div[3]/div/div/button')
            if q:
                q.click()
                time.sleep(1)
                driver.find_elements_by_xpath('//*[@id="root"]/div[1]/div[2]/div[3]/div/div[1]/button').click()
        except:
            pass

        typing()
        
        try:
            q = driver.find_elements_by_xpath('//*[@id="root"]/div[1]/div[1]/div[3]/div/div[2]/button')
            if q:
                q.click()
                time.sleep(1)
                driver.find_elements_by_xpath('//*[@id="root"]/div[1]/div[2]/div[3]/div/div[1]/button').click()
        except:
            pass
        

elif inputnumb == 2:
#bot guest
     
    import string
    import pyautogui
    import time
    from bs4 import BeautifulSoup
    import random
    driver = webdriver.Chrome(chromedriverdir)
    driver.implicitly_wait(5)
    driver.get('https://www.nitrotype.com/race')
    try:
        if driver.find_element_by_xpath('//*[@id="qc-cmp2-ui"]/div[2]/div/button[2]'):
                driver.find_element_by_xpath('//*[@id="qc-cmp2-ui"]/div[2]/div/button[2]').click()
    except:
        pass
    driver.find_element_by_xpath('//*[@id="raceContainer"]/div[3]/div[1]/div[1]/div[3]/div/button').click()
    def what():
        htmlsrc = driver.page_source
        htmlpaste = open('textfiles/html_src.txt', 'w')
        htmlpaste.write(htmlsrc)
        htmlpaste.close()
        htmlreplace = open("textfiles/html_src.txt", "rt")
        data = htmlreplace.read()
        htmlreplace.close()
        data = data.replace('&nbsp;', ' ')
        htmlreplace = open("textfiles/html_src.txt", "wt")
        htmlreplace.write(data)
        htmlreplace.close()
        htmlfile = open('textfiles/html_src.txt', 'r')
        soup = BeautifulSoup(htmlfile, 'lxml')
        htmlfile.close()
        span = soup.find_all('span', class_='dash-letter')
        with open('textfiles/spans.txt', 'w') as f:
            for spans in span:
                f.write(spans.text)
            f.close()
        spantxt = open('textfiles/spans.txt', 'r+')
        spantxtdata = spantxt.read()
        spantxt.close()
        spans2txt = open('textfiles/span2.txt', 'r+')
        for word in spantxtdata:
            listword = list(word)
            for letter in listword:
                spans2txt.write(letter + '\n')
        spans2txt.close()
        def randomdec():
            rando = random.randint(1,30)
            if rando == 1:
                time.sleep(0.1)
            if rando == 2:
                time.sleep(0.2)
            else:
                time.sleep(0)
        def randommistake():
            randlet = random.randint(1,50)
            if randlet == 1:
                string.ascii_letters
                pyautogui.typewrite(random.choice(string.ascii_letters))
        writetype = open('textfiles/span2.txt', 'r+')
        for letter in writetype:
            letter = letter.strip('\n')
            pyautogui.typewrite(letter)
            randomdec()
            randommistake()
        writetype.truncate(0)
        writetype.close()
    def typing():
        try:
            q = driver.find_element_by_xpath('//*[@id="raceContainer"]/div[3]/div[1]/div[1]/div[2]/div[2]')
            if q:
                q.click()
                what()
            else:
                pass
        except:
            pass            
    while True:
        typing()
        try:
            q = driver.find_element_by_xpath('//*[@id="root"]/div[1]/div/div[1]/button')
            if q:
                q.click()
        except:
            pass

        typing()

        try:
            q = driver.find_element_by_xpath('//*[@id="raceContainer"]/div[1]/div[2]/div[3]/div/div[2]/button')
            if q:
                q.click()
        except:
            pass

        typing()

        try:
            q = driver.find_elements_by_xpath('//*[@id="raceContainer"]/div[1]/div[1]/div/div/div/div[2]/button')
            if q:
                q.click()
        except:
            pass

        typing()

        try:
            q = driver.find_elements_by_xpath('//*[@id="root"]/div[1]/div[1]/div[3]/div/div/button')
            if q:
                q.click()
                time.sleep(1)
                driver.find_elements_by_xpath('//*[@id="root"]/div[1]/div[2]/div[3]/div/div[1]/button').click()
        except:
            pass

        typing()
        
        try:
            q = driver.find_elements_by_xpath('//*[@id="root"]/div[1]/div[1]/div[3]/div/div[2]/button')
            if q:
                q.click()
                time.sleep(1)
                driver.find_elements_by_xpath('//*[@id="root"]/div[1]/div[2]/div[3]/div/div[1]/button').click()
        except:
            pass

elif inputnumb == 3:
#bot guest instant
     
    import string
    import pyautogui
    import time
    from bs4 import BeautifulSoup
    import random
    driver = webdriver.Chrome(chromedriverdir)
    driver.implicitly_wait(5)
    driver.get('https://www.nitrotype.com/race')
    try:
        if driver.find_element_by_xpath('//*[@id="qc-cmp2-ui"]/div[2]/div/button[2]'):
                driver.find_element_by_xpath('//*[@id="qc-cmp2-ui"]/div[2]/div/button[2]').click()
    except:
        pass
    driver.find_element_by_xpath('//*[@id="raceContainer"]/div[3]/div[1]/div[1]/div[3]/div/button').click()
    def what():
        htmlsrc = driver.page_source
        htmlpaste = open('textfiles/html_src.txt', 'w')
        htmlpaste.write(htmlsrc)
        htmlpaste.close()
        htmlreplace = open("textfiles/html_src.txt", "rt")
        data = htmlreplace.read()
        htmlreplace.close()
        data = data.replace('&nbsp;', ' ')
        htmlreplace = open("textfiles/html_src.txt", "wt")
        htmlreplace.write(data)
        htmlreplace.close()
        htmlfile = open('textfiles/html_src.txt', 'r')
        soup = BeautifulSoup(htmlfile, 'lxml')
        htmlfile.close()
        span = soup.find_all('span', class_='dash-letter')
        with open('textfiles/spans.txt', 'w') as f:
            for spans in span:
                f.write(spans.text)
            f.close()
        writetype = open('textfiles/spans.txt', 'r+')
        for letter in writetype:
            letter = letter.strip('\n')
            pyautogui.typewrite(letter)
        writetype.truncate(0)
        writetype.close()
    def typing():
        try:
            q = driver.find_element_by_xpath('//*[@id="raceContainer"]/div[3]/div[1]/div[1]/div[2]/div[2]')
            if q:
                q.click()
                what()
            else:
                pass
        except:
            pass              
    while True:
        typing()

        try:
            q = driver.find_element_by_xpath('//*[@id="root"]/div[1]/div/div[1]/button')
            if q:
                q.click()
        except:
            pass

        typing()

        try:
            q = driver.find_element_by_xpath('//*[@id="raceContainer"]/div[1]/div[2]/div[3]/div/div[2]/button')
            if q:
                q.click()
        except:
            pass

        typing()

        try:
            q = driver.find_elements_by_xpath('//*[@id="raceContainer"]/div[1]/div[1]/div/div/div/div[2]/button')
            if q:
                q.click()
        except:
            pass

        typing()

        try:
            q = driver.find_elements_by_xpath('//*[@id="root"]/div[1]/div[1]/div[3]/div/div/button')
            if q:
                q.click()
                time.sleep(1)
                driver.find_elements_by_xpath('//*[@id="root"]/div[1]/div[2]/div[3]/div/div[1]/button').click()
        except:
            pass

        typing()
        
        try:
            q = driver.find_elements_by_xpath('//*[@id="root"]/div[1]/div[1]/div[3]/div/div[2]/button')
            if q:
                q.click()
                time.sleep(1)
                driver.find_elements_by_xpath('//*[@id="root"]/div[1]/div[2]/div[3]/div/div[1]/button').click()
        except:
            pass

elif inputnumb == 4:
#Bot manual
     
    import string
    import pyautogui
    import time
    
    from bs4 import BeautifulSoup
    import random
    import keyboard
    perfectint = input("No mistakes (warning: could trigger anticheat if used long enough) (y/n): ")
    driver = webdriver.Chrome(chromedriverdir)
    driver.implicitly_wait(5)
    driver.get('https://www.nitrotype.com/login')

    if perfectint == "n" or perfectint == "no":
        def what():
            htmlsrc = driver.page_source
            htmlpaste = open('textfiles/html_src.txt', 'w')
            htmlpaste.write(htmlsrc)
            htmlpaste.close()
            htmlreplace = open("textfiles/html_src.txt", "rt")
            data = htmlreplace.read()
            htmlreplace.close()
            data = data.replace('&nbsp;', ' ')
            htmlreplace = open("textfiles/html_src.txt", "wt")
            htmlreplace.write(data)
            htmlreplace.close()
            htmlfile = open('textfiles/html_src.txt', 'r')
            soup = BeautifulSoup(htmlfile, 'lxml')
            htmlfile.close()
            span = soup.find_all('span', class_='dash-letter')
            with open('textfiles/spans.txt', 'w') as f:
                for spans in span:
                    f.write(spans.text)
                f.close()
            spantxt = open('textfiles/spans.txt', 'r+')
            spantxtdata = spantxt.read()
            spantxt.close()

            spans2txt = open('textfiles/span2.txt', 'r+')
            for word in spantxtdata:
                listword = list(word)
                for letter in listword:
                    spans2txt.write(letter + '\n')
            spans2txt.close()
            def randomdec():
                rando = random.randint(1,30)
                if rando == 1:
                    time.sleep(0.1)
                if rando == 2:
                    time.sleep(0.2)
                else:
                    time.sleep(0)
            def randommistake():
                randlet = random.randint(1,50)
                if randlet == 1:
                    string.ascii_letters
                    pyautogui.typewrite(random.choice(string.ascii_letters))
            writetype = open('textfiles/span2.txt', 'r+')
            for letter in writetype:
                letter = letter.strip('\n')
                pyautogui.typewrite(letter)
                randomdec()
                randommistake()
            writetype.truncate(0)
            writetype.close()                
        while True:
            if keyboard.is_pressed('`'):
                what()

    if perfectint == "y" or perfectint == "yes":
        def what():
            htmlsrc = driver.page_source
            htmlpaste = open('textfiles/html_src.txt', 'w')
            htmlpaste.write(htmlsrc)
            htmlpaste.close()
            htmlreplace = open("textfiles/html_src.txt", "rt")
            data = htmlreplace.read()
            htmlreplace.close()
            data = data.replace('&nbsp;', ' ')
            htmlreplace = open("textfiles/html_src.txt", "wt")
            htmlreplace.write(data)
            htmlreplace.close()
            htmlfile = open('textfiles/html_src.txt', 'r')
            soup = BeautifulSoup(htmlfile, 'lxml')
            htmlfile.close()
            span = soup.find_all('span', class_='dash-letter')
            with open('textfiles/spans.txt', 'w') as f:
                for spans in span:
                    f.write(spans.text)
                f.close()
            spantxt = open('textfiles/spans.txt', 'r+')
            spantxtdata = spantxt.read()
            spantxt.close()
            spans2txt = open('textfiles/span2.txt', 'r+')
            for word in spantxtdata:
                listword = list(word)
                for letter in listword:
                    spans2txt.write(letter + '\n')
            spans2txt.close()
            writetype = open('textfiles/span2.txt', 'r+')
            for letter in writetype:
                letter = letter.strip('\n')
                pyautogui.typewrite(letter)
            writetype.truncate(0)
            writetype.close()                  
        while True:
            if keyboard.is_pressed('`') or keyboard.is_pressed('~'):
                what()

elif inputnumb == 5:
     
    import string
    import pyautogui
    import time
    
    from bs4 import BeautifulSoup
    import random
    import keyboard
    driver = webdriver.Chrome(chromedriverdir)
    driver.implicitly_wait(5)
    driver.get('https://www.nitrotype.com/race')
    def what():
        htmlsrc = driver.page_source
        htmlpaste = open('textfiles/html_src.txt', 'w')
        htmlpaste.write(htmlsrc)
        htmlpaste.close()
        htmlreplace = open("textfiles/html_src.txt", "rt")
        data = htmlreplace.read()
        htmlreplace.close()
        data = data.replace('&nbsp;', ' ')
        htmlreplace = open("textfiles/html_src.txt", "wt")
        htmlreplace.write(data)
        htmlreplace.close()
        htmlfile = open('textfiles/html_src.txt', 'r')
        soup = BeautifulSoup(htmlfile, 'lxml')
        htmlfile.close()
        span = soup.find_all('span', class_='dash-letter')
        with open('textfiles/spans.txt', 'w') as f:
            for spans in span:
                f.write(spans.text)
            f.close()
        writetype = open('textfiles/spans.txt', 'r+')
        for letter in writetype:
            letter = letter.strip('\n')
            pyautogui.typewrite(letter)
        writetype.truncate(0)
        writetype.close()            
    while True:
        if keyboard.is_pressed('`'):
            what()

elif inputnumb == 6:
    driver = webdriver.Chrome(chromedriverdir)
    driver.implicitly_wait(5)
    driver.get('https://youtu.be/2nO6XmRdjaI')
    time.sleep(69420)

else:
    print ("Not a valid option")

